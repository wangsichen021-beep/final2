from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

from lerobot.configs.types import FeatureType, PolicyFeature
from lerobot.policies.act.configuration_act import ACTConfig
from lerobot.policies.act.modeling_act import ACTPolicy

from calvin_act_common import (
    CalvinActDataset,
    CalvinStats,
    SPLIT_TEST,
    SPLITS_TRAIN,
    denormalize_actions,
    move_batch_to_device,
)


def build_policy(args: argparse.Namespace) -> ACTPolicy:
    config = ACTConfig(
        input_features={
            "observation.state": PolicyFeature(type=FeatureType.STATE, shape=(15,)),
            "observation.images.image": PolicyFeature(
                type=FeatureType.VISUAL, shape=(3, args.image_size, args.image_size)
            ),
            "observation.images.wrist_image": PolicyFeature(
                type=FeatureType.VISUAL, shape=(3, args.image_size, args.image_size)
            ),
        },
        output_features={"action": PolicyFeature(type=FeatureType.ACTION, shape=(7,))},
        device=args.device,
        use_amp=args.amp,
        chunk_size=args.chunk_size,
        n_action_steps=args.chunk_size,
        pretrained_backbone_weights=None,
        dim_model=args.dim_model,
        n_heads=args.n_heads,
        dim_feedforward=args.dim_feedforward,
        n_encoder_layers=args.n_encoder_layers,
        n_decoder_layers=args.n_decoder_layers,
        n_vae_encoder_layers=args.n_vae_encoder_layers,
        latent_dim=args.latent_dim,
        kl_weight=args.kl_weight,
        dropout=args.dropout,
    )
    return ACTPolicy(config)


@torch.no_grad()
def evaluate(policy: ACTPolicy, loader: DataLoader, stats: CalvinStats, device: torch.device, max_batches: int) -> dict:
    policy.eval()
    total_l1 = 0.0
    total_raw_l1 = 0.0
    total_count = 0
    for i, batch in enumerate(loader):
        if i >= max_batches:
            break
        batch = move_batch_to_device(batch, device)
        model_batch = dict(batch)
        model_batch["observation.images"] = [model_batch[key] for key in policy.config.image_features]
        pred_norm, _ = policy.model(model_batch)
        valid = (~batch["action_is_pad"]).unsqueeze(-1)
        norm_l1 = (torch.abs(pred_norm - batch["action"]) * valid).sum() / valid.sum().clamp_min(1)

        pred_raw = denormalize_actions(pred_norm, stats, device)
        gt_raw = denormalize_actions(batch["action"], stats, device)
        raw_l1 = (torch.abs(pred_raw - gt_raw) * valid).sum() / valid.sum().clamp_min(1)

        bs = batch["action"].shape[0]
        total_l1 += float(norm_l1.item()) * bs
        total_raw_l1 += float(raw_l1.item()) * bs
        total_count += bs
    return {
        "loss": total_l1 / max(total_count, 1),
        "l1_loss": total_l1 / max(total_count, 1),
        "kld_loss": 0.0,
        "raw_action_l1": total_raw_l1 / max(total_count, 1),
    }


def append_csv(path: Path, row: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    write_header = not path.exists()
    with path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(row.keys()))
        if write_header:
            writer.writeheader()
        writer.writerow(row)


def save_checkpoint(path: Path, policy: ACTPolicy, optimizer: torch.optim.Optimizer, step: int, args, stats_path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "step": step,
            "model": policy.state_dict(),
            "optimizer": optimizer.state_dict(),
            "args": vars(args),
            "stats_path": str(stats_path),
        },
        path,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--stats", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--train-splits", nargs="+", default=list(SPLITS_TRAIN))
    parser.add_argument("--eval-split", default=SPLIT_TEST)
    parser.add_argument("--chunk-size", type=int, default=20)
    parser.add_argument("--image-size", type=int, default=128)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--num-workers", type=int, default=8)
    parser.add_argument("--steps", type=int, default=20000)
    parser.add_argument("--samples-per-epoch", type=int, default=100000)
    parser.add_argument("--eval-batches", type=int, default=50)
    parser.add_argument("--eval-every", type=int, default=1000)
    parser.add_argument("--save-every", type=int, default=5000)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--dim-model", type=int, default=256)
    parser.add_argument("--n-heads", type=int, default=4)
    parser.add_argument("--dim-feedforward", type=int, default=1024)
    parser.add_argument("--n-encoder-layers", type=int, default=4)
    parser.add_argument("--n-decoder-layers", type=int, default=1)
    parser.add_argument("--n-vae-encoder-layers", type=int, default=4)
    parser.add_argument("--latent-dim", type=int, default=32)
    parser.add_argument("--kl-weight", type=float, default=10.0)
    parser.add_argument("--dropout", type=float, default=0.1)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--amp", action="store_true")
    parser.add_argument("--max-episodes-per-split", type=int, default=None)
    parser.add_argument("--resume", type=Path, default=None)
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    with (args.output_dir / "config.json").open("w", encoding="utf-8") as f:
        json.dump(vars(args), f, indent=2, default=str)

    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    stats = CalvinStats.load(args.stats)

    train_ds = CalvinActDataset(
        args.data_root,
        args.train_splits,
        stats,
        chunk_size=args.chunk_size,
        image_size=args.image_size,
        samples_per_epoch=args.samples_per_epoch,
        max_episodes_per_split=args.max_episodes_per_split,
    )
    eval_ds = CalvinActDataset(
        args.data_root,
        [args.eval_split],
        stats,
        chunk_size=args.chunk_size,
        image_size=args.image_size,
        samples_per_epoch=args.eval_batches * args.batch_size,
        max_episodes_per_split=args.max_episodes_per_split,
        deterministic=True,
    )
    train_loader = DataLoader(
        train_ds,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=True,
        persistent_workers=args.num_workers > 0,
        drop_last=True,
    )
    eval_loader = DataLoader(
        eval_ds,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=max(1, args.num_workers // 2),
        pin_memory=True,
        persistent_workers=args.num_workers > 0,
    )

    policy = build_policy(args).to(device)
    optimizer = torch.optim.AdamW(policy.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scaler = torch.amp.GradScaler("cuda", enabled=args.amp and device.type == "cuda")

    start_step = 0
    if args.resume is not None:
        ckpt = torch.load(args.resume, map_location=device)
        policy.load_state_dict(ckpt["model"])
        optimizer.load_state_dict(ckpt["optimizer"])
        start_step = int(ckpt.get("step", 0))

    log_path = args.output_dir / "metrics.csv"
    step = start_step
    data_iter = iter(train_loader)
    pbar = tqdm(total=args.steps, initial=step, desc="train")
    while step < args.steps:
        try:
            batch = next(data_iter)
        except StopIteration:
            data_iter = iter(train_loader)
            batch = next(data_iter)

        policy.train()
        batch = move_batch_to_device(batch, device)
        optimizer.zero_grad(set_to_none=True)
        with torch.amp.autocast("cuda", enabled=args.amp and device.type == "cuda"):
            loss, loss_dict = policy(batch)
        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        grad_norm = torch.nn.utils.clip_grad_norm_(policy.parameters(), 1.0)
        scaler.step(optimizer)
        scaler.update()

        step += 1
        pbar.update(1)
        if step % 20 == 0:
            pbar.set_postfix(loss=f"{loss.item():.4f}", l1=f"{loss_dict.get('l1_loss', math.nan):.4f}")

        if step == 1 or step % args.eval_every == 0:
            eval_metrics = evaluate(policy, eval_loader, stats, device, args.eval_batches)
            row = {
                "step": step,
                "train_loss": float(loss.item()),
                "train_l1_loss": float(loss_dict.get("l1_loss", 0.0)),
                "train_kld_loss": float(loss_dict.get("kld_loss", 0.0)),
                "grad_norm": float(grad_norm),
                "eval_loss": eval_metrics["loss"],
                "eval_l1_loss": eval_metrics["l1_loss"],
                "eval_kld_loss": eval_metrics["kld_loss"],
                "eval_raw_action_l1": eval_metrics["raw_action_l1"],
            }
            append_csv(log_path, row)
            print(json.dumps(row), flush=True)

        if step % args.save_every == 0 or step == args.steps:
            save_checkpoint(args.output_dir / f"checkpoint_step_{step}.pt", policy, optimizer, step, args, args.stats)
            save_checkpoint(args.output_dir / "checkpoint_latest.pt", policy, optimizer, step, args, args.stats)

    pbar.close()
    save_checkpoint(args.output_dir / "checkpoint_final.pt", policy, optimizer, step, args, args.stats)


if __name__ == "__main__":
    main()
