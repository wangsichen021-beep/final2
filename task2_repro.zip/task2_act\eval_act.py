from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import torch
from torch.utils.data import DataLoader

from calvin_act_common import CalvinActDataset, CalvinStats
from train_act import build_policy, evaluate


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--stats", type=Path, required=True)
    parser.add_argument("--split", default="splitD")
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--num-workers", type=int, default=8)
    parser.add_argument("--eval-batches", type=int, default=200)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    ckpt = torch.load(args.checkpoint, map_location="cpu")
    train_args = argparse.Namespace(**ckpt["args"])
    device = torch.device(train_args.device if torch.cuda.is_available() else "cpu")
    stats = CalvinStats.load(args.stats)
    policy = build_policy(train_args).to(device)
    policy.load_state_dict(ckpt["model"])

    ds = CalvinActDataset(
        args.data_root,
        [args.split],
        stats,
        chunk_size=train_args.chunk_size,
        image_size=train_args.image_size,
        samples_per_epoch=args.eval_batches * args.batch_size,
        deterministic=True,
    )
    loader = DataLoader(
        ds,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=True,
        persistent_workers=args.num_workers > 0,
    )
    metrics = evaluate(policy, loader, stats, device, args.eval_batches)
    metrics["checkpoint"] = str(args.checkpoint)
    metrics["split"] = args.split
    metrics["chunk_size"] = train_args.chunk_size

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)
    csv_path = args.output.with_suffix(".csv")
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(metrics.keys()))
        writer.writeheader()
        writer.writerow(metrics)
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()

