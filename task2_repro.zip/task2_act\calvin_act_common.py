from __future__ import annotations

import io
import json
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import pyarrow.parquet as pq
import torch
from PIL import Image
from torch.utils.data import Dataset


SPLITS_TRAIN = ("splitA", "splitB", "splitC")
SPLIT_TEST = "splitD"


@dataclass
class CalvinStats:
    state_mean: np.ndarray
    state_std: np.ndarray
    action_mean: np.ndarray
    action_std: np.ndarray

    @classmethod
    def load(cls, path: str | Path) -> "CalvinStats":
        data = np.load(path)
        return cls(
            state_mean=data["state_mean"].astype(np.float32),
            state_std=data["state_std"].astype(np.float32),
            action_mean=data["action_mean"].astype(np.float32),
            action_std=data["action_std"].astype(np.float32),
        )

    def save(self, path: str | Path) -> None:
        np.savez(
            path,
            state_mean=self.state_mean,
            state_std=self.state_std,
            action_mean=self.action_mean,
            action_std=self.action_std,
        )


def list_episode_files(data_root: str | Path, splits: Iterable[str]) -> list[Path]:
    root = Path(data_root)
    files: list[Path] = []
    for split in splits:
        split_files = sorted((root / split / "data").glob("chunk-*/*.parquet"))
        if not split_files:
            raise FileNotFoundError(f"No parquet files found for {split} under {root}")
        files.extend(split_files)
    return files


def load_task_map(data_root: str | Path, split: str = "splitA") -> dict[int, str]:
    tasks_path = Path(data_root) / split / "meta" / "tasks.jsonl"
    task_map: dict[int, str] = {}
    if not tasks_path.exists():
        return task_map
    with tasks_path.open("r", encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            item = json.loads(line)
            idx = item.get("task_index", item.get("index"))
            task = item.get("task", item.get("task_description", ""))
            if idx is not None:
                task_map[int(idx)] = str(task)
    return task_map


def decode_image(image_cell: dict, image_size: int) -> torch.Tensor:
    img_bytes = image_cell["bytes"]
    img = Image.open(io.BytesIO(img_bytes)).convert("RGB")
    if img.size != (image_size, image_size):
        img = img.resize((image_size, image_size), Image.BILINEAR)
    arr = np.asarray(img, dtype=np.float32) / 255.0
    arr = (arr - 0.5) / 0.5
    arr = np.transpose(arr, (2, 0, 1))
    return torch.from_numpy(arr)


def read_episode(path: Path) -> dict:
    table = pq.read_table(path, columns=["image", "wrist_image", "state", "actions", "task_index"])
    return table.to_pydict()


class CalvinActDataset(Dataset):
    def __init__(
        self,
        data_root: str | Path,
        splits: Iterable[str],
        stats: CalvinStats,
        chunk_size: int = 20,
        image_size: int = 128,
        samples_per_epoch: int | None = None,
        max_episodes_per_split: int | None = None,
        deterministic: bool = False,
    ) -> None:
        self.data_root = Path(data_root)
        self.splits = tuple(splits)
        self.stats = stats
        self.chunk_size = int(chunk_size)
        self.image_size = int(image_size)
        self.samples_per_epoch = samples_per_epoch
        self.deterministic = deterministic

        files: list[Path] = []
        for split in self.splits:
            split_files = sorted((self.data_root / split / "data").glob("chunk-*/*.parquet"))
            if max_episodes_per_split is not None:
                split_files = split_files[:max_episodes_per_split]
            files.extend(split_files)
        if not files:
            raise FileNotFoundError(f"No parquet files found under {self.data_root} for {self.splits}")
        self.files = files

    def __len__(self) -> int:
        return self.samples_per_epoch or len(self.files)

    def __getitem__(self, idx: int) -> dict[str, torch.Tensor]:
        if self.samples_per_epoch is not None:
            file_idx = random.randrange(len(self.files))
        else:
            file_idx = idx % len(self.files)
        path = self.files[file_idx]
        ep = read_episode(path)
        n = len(ep["actions"])
        if n <= 0:
            raise ValueError(f"Empty episode: {path}")

        if self.deterministic:
            t = min(idx % max(n, 1), n - 1)
        else:
            t = random.randrange(n)

        state = np.asarray(ep["state"][t], dtype=np.float32)
        state = (state - self.stats.state_mean) / self.stats.state_std

        actions = np.zeros((self.chunk_size, 7), dtype=np.float32)
        action_is_pad = np.ones((self.chunk_size,), dtype=bool)
        end = min(n, t + self.chunk_size)
        valid = end - t
        if valid > 0:
            act = np.asarray(ep["actions"][t:end], dtype=np.float32)
            act = (act - self.stats.action_mean) / self.stats.action_std
            actions[:valid] = act
            action_is_pad[:valid] = False

        return {
            "observation.state": torch.from_numpy(state),
            "observation.images.image": decode_image(ep["image"][t], self.image_size),
            "observation.images.wrist_image": decode_image(ep["wrist_image"][t], self.image_size),
            "action": torch.from_numpy(actions),
            "action_is_pad": torch.from_numpy(action_is_pad),
        }


def move_batch_to_device(batch: dict[str, torch.Tensor], device: torch.device) -> dict[str, torch.Tensor]:
    return {k: v.to(device, non_blocking=True) if torch.is_tensor(v) else v for k, v in batch.items()}


def denormalize_actions(action_norm: torch.Tensor, stats: CalvinStats, device: torch.device) -> torch.Tensor:
    mean = torch.as_tensor(stats.action_mean, dtype=action_norm.dtype, device=device)
    std = torch.as_tensor(stats.action_std, dtype=action_norm.dtype, device=device)
    return action_norm * std + mean

