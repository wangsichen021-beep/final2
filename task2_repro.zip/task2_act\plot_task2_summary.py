from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


def read_metric(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    df["step"] = df["step"].astype(int)
    return df


def load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results-root", type=Path, default=Path("task2_results"))
    parser.add_argument("--output-dir", type=Path, default=Path("task2_results/figures"))
    args = parser.parse_args()

    root = args.results_root
    out = args.output_dir
    out.mkdir(parents=True, exist_ok=True)

    base_metrics = root / "outputs" / "act_base_splitB" / "metrics.csv"
    joint_metrics = root / "outputs" / "act_chunk20" / "metrics.csv"
    if base_metrics.exists() and joint_metrics.exists():
        base = read_metric(base_metrics)
        joint = read_metric(joint_metrics)

        plt.figure(figsize=(7, 4.2))
        plt.plot(base["step"], base["train_l1_loss"], label="Base ACT, train on B")
        plt.plot(joint["step"], joint["train_l1_loss"], label="Joint ACT, train on A+B+C")
        plt.xlabel("Training step")
        plt.ylabel("Train Action L1 Loss")
        plt.title("Convergence Comparison")
        plt.grid(True, alpha=0.3)
        plt.legend()
        plt.tight_layout()
        plt.savefig(out / "convergence_train_l1.png", dpi=200)
        plt.close()

        plt.figure(figsize=(7, 4.2))
        plt.plot(base["step"], base["eval_raw_action_l1"], label="Base ACT validation on B")
        plt.plot(joint["step"], joint["eval_raw_action_l1"], label="Joint ACT zero-shot on D")
        plt.xlabel("Training step")
        plt.ylabel("Raw Action L1")
        plt.title("Validation / Zero-Shot Action Error During Training")
        plt.grid(True, alpha=0.3)
        plt.legend()
        plt.tight_layout()
        plt.savefig(out / "eval_raw_action_l1_curves.png", dpi=200)
        plt.close()

    zero_shot = [
        ("Base B -> D", root / "outputs" / "act_base_splitB" / "eval_splitD.json"),
        ("Joint ABC -> D", root / "outputs" / "act_chunk20" / "eval_splitD.json"),
    ]
    zero_rows = [(name, load_json(path)["raw_action_l1"]) for name, path in zero_shot if path.exists()]
    if zero_rows:
        labels, values = zip(*zero_rows)
        plt.figure(figsize=(5.6, 4.0))
        plt.bar(labels, values, color=["#5B8FF9", "#61DDAA"])
        plt.ylabel("Raw Action L1 on splitD")
        plt.title("Zero-Shot Cross-Environment Test")
        plt.grid(True, axis="y", alpha=0.3)
        for i, v in enumerate(values):
            plt.text(i, v, f"{v:.3f}", ha="center", va="bottom")
        plt.tight_layout()
        plt.savefig(out / "zero_shot_splitD_action_error.png", dpi=200)
        plt.close()

    chunks = [
        ("10", root / "outputs" / "act_chunk10_10k" / "eval_splitD.json"),
        ("20", root / "outputs" / "act_chunk20" / "eval_splitD_step10000.json"),
        ("30", root / "outputs" / "act_chunk30_10k" / "eval_splitD.json"),
    ]
    chunk_rows = [(name, load_json(path)["raw_action_l1"]) for name, path in chunks if path.exists()]
    if chunk_rows:
        labels, values = zip(*chunk_rows)
        plt.figure(figsize=(5.6, 4.0))
        plt.bar(labels, values, color="#65789B")
        plt.xlabel("ACT chunk size")
        plt.ylabel("Raw Action L1 on splitD")
        plt.title("Action Chunking Under Visual Shift")
        plt.grid(True, axis="y", alpha=0.3)
        for i, v in enumerate(values):
            plt.text(i, v, f"{v:.3f}", ha="center", va="bottom")
        plt.tight_layout()
        plt.savefig(out / "action_chunking_splitD.png", dpi=200)
        plt.close()

    print(f"Saved figures to {out}")


if __name__ == "__main__":
    main()

