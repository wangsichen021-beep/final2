#!/usr/bin/env bash
set -euo pipefail
source /root/miniconda3/etc/profile.d/conda.sh
conda activate /root/autodl-tmp/envs/calvin-act
cd /root/autodl-tmp/calvin_act_hw3/task2_act

DATA=/root/autodl-tmp/calvin_act_hw3/calvin-lerobot
OUT_ROOT=/root/autodl-tmp/calvin_act_hw3/outputs
STATS=$OUT_ROOT/stats_abc_full.npz

if [ ! -f "$STATS" ]; then
  python prepare_stats.py --data-root "$DATA" --output "$STATS"
fi

python train_act.py \
  --data-root "$DATA" \
  --stats "$STATS" \
  --output-dir "$OUT_ROOT/act_chunk20" \
  --chunk-size 20 \
  --image-size 128 \
  --batch-size 32 \
  --num-workers 8 \
  --steps 20000 \
  --samples-per-epoch 100000 \
  --eval-batches 50 \
  --eval-every 1000 \
  --save-every 5000 \
  --amp

python eval_act.py \
  --checkpoint "$OUT_ROOT/act_chunk20/checkpoint_final.pt" \
  --data-root "$DATA" \
  --stats "$STATS" \
  --split splitD \
  --batch-size 32 \
  --num-workers 8 \
  --eval-batches 200 \
  --output "$OUT_ROOT/act_chunk20/eval_splitD.json"

python plot_results.py \
  --metrics "$OUT_ROOT/act_chunk20/metrics.csv" \
  --output "$OUT_ROOT/act_chunk20/loss_curve.png"

