from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pyarrow.parquet as pq
from tqdm import tqdm

from calvin_act_common import CalvinStats, SPLITS_TRAIN, list_episode_files


def update(sum_: np.ndarray, sumsq: np.ndarray, count: int, arr: np.ndarray) -> tuple[np.ndarray, np.ndarray, int]:
    arr = arr.astype(np.float64)
    sum_ += arr.sum(axis=0)
    sumsq += (arr * arr).sum(axis=0)
    count += arr.shape[0]
    return sum_, sumsq, count


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--splits", nargs="+", default=list(SPLITS_TRAIN))
    parser.add_argument("--max-episodes-per-split", type=int, default=None)
    args = parser.parse_args()

    files = []
    for split in args.splits:
        split_files = sorted((args.data_root / split / "data").glob("chunk-*/*.parquet"))
        if args.max_episodes_per_split is not None:
            split_files = split_files[: args.max_episodes_per_split]
        files.extend(split_files)
    if not files:
        raise FileNotFoundError(f"No episode files found under {args.data_root}")

    state_sum = np.zeros(15, dtype=np.float64)
    state_sumsq = np.zeros(15, dtype=np.float64)
    action_sum = np.zeros(7, dtype=np.float64)
    action_sumsq = np.zeros(7, dtype=np.float64)
    state_count = 0
    action_count = 0

    for path in tqdm(files, desc="stats"):
        table = pq.read_table(path, columns=["state", "actions"])
        data = table.to_pydict()
        states = np.asarray(data["state"], dtype=np.float32)
        actions = np.asarray(data["actions"], dtype=np.float32)
        state_sum, state_sumsq, state_count = update(state_sum, state_sumsq, state_count, states)
        action_sum, action_sumsq, action_count = update(action_sum, action_sumsq, action_count, actions)

    state_mean = state_sum / state_count
    action_mean = action_sum / action_count
    state_std = np.sqrt(np.maximum(state_sumsq / state_count - state_mean * state_mean, 1e-8))
    action_std = np.sqrt(np.maximum(action_sumsq / action_count - action_mean * action_mean, 1e-8))
    state_std = np.maximum(state_std, 1e-6)
    action_std = np.maximum(action_std, 1e-6)

    stats = CalvinStats(
        state_mean=state_mean.astype(np.float32),
        state_std=state_std.astype(np.float32),
        action_mean=action_mean.astype(np.float32),
        action_std=action_std.astype(np.float32),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    stats.save(args.output)
    print(f"Saved stats to {args.output}")
    print("state_mean", stats.state_mean)
    print("state_std", stats.state_std)
    print("action_mean", stats.action_mean)
    print("action_std", stats.action_std)


if __name__ == "__main__":
    main()

