from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--metrics", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    df = pd.read_csv(args.metrics)
    args.output.parent.mkdir(parents=True, exist_ok=True)

    plt.figure(figsize=(8, 5))
    plt.plot(df["step"], df["train_l1_loss"], label="train normalized L1")
    plt.plot(df["step"], df["eval_l1_loss"], label="D normalized L1")
    plt.xlabel("Step")
    plt.ylabel("L1 loss")
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(args.output)
    print(f"Saved {args.output}")

    raw_path = args.output.with_name(args.output.stem + "_raw_action_l1.png")
    plt.figure(figsize=(8, 5))
    plt.plot(df["step"], df["eval_raw_action_l1"], label="D raw action L1")
    plt.xlabel("Step")
    plt.ylabel("Raw action L1")
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(raw_path)
    print(f"Saved {raw_path}")


if __name__ == "__main__":
    main()

