#!/usr/bin/env bash
set -euo pipefail
source /root/miniconda3/etc/profile.d/conda.sh
conda activate /root/autodl-tmp/envs/calvin-act
cd /root/autodl-tmp/calvin_act_hw3/task2_act

DATA=/root/autodl-tmp/calvin_act_hw3/calvin-lerobot
OUT_ROOT=/root/autodl-tmp/calvin_act_hw3/outputs
STATS=$OUT_ROOT/stats_b_full.npz
OUT=$OUT_ROOT/act_base_splitB

if [ ! -f "$STATS" ]; then
  python prepare_stats.py \
    --data-root "$DATA" \
    --splits splitB \
    --output "$STATS"
fi

python train_act.py \
  --data-root "$DATA" \
  --stats "$STATS" \
  --output-dir "$OUT" \
  --train-splits splitB \
  --eval-split splitB \
  --chunk-size 20 \
  --image-size 128 \
  --batch-size 32 \
  --num-workers 8 \
  --steps 20000 \
  --samples-per-epoch 100000 \
  --eval-batches 50 \
  --eval-every 1000 \
  --save-every 5000 \
  --amp

python eval_act.py \
  --checkpoint "$OUT/checkpoint_final.pt" \
  --data-root "$DATA" \
  --stats "$STATS" \
  --split splitB \
  --batch-size 32 \
  --num-workers 8 \
  --eval-batches 200 \
  --output "$OUT/eval_splitB.json"

python eval_act.py \
  --checkpoint "$OUT/checkpoint_final.pt" \
  --data-root "$DATA" \
  --stats "$STATS" \
  --split splitD \
  --batch-size 32 \
  --num-workers 8 \
  --eval-batches 200 \
  --output "$OUT/eval_splitD.json"

python plot_results.py \
  --metrics "$OUT/metrics.csv" \
  --output "$OUT/loss_curve.png"
