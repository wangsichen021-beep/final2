#!/usr/bin/env bash
set -euo pipefail
source /root/miniconda3/etc/profile.d/conda.sh
conda activate /root/autodl-tmp/envs/calvin-act
cd /root/autodl-tmp/calvin_act_hw3/task2_act

DATA=/root/autodl-tmp/calvin_act_hw3/calvin-lerobot
OUT=/root/autodl-tmp/calvin_act_hw3/outputs/smoke_chunk20
STATS=/root/autodl-tmp/calvin_act_hw3/outputs/stats_abc_smoke.npz

python prepare_stats.py --data-root "$DATA" --output "$STATS" --max-episodes-per-split 50
python train_act.py \
  --data-root "$DATA" \
  --stats "$STATS" \
  --output-dir "$OUT" \
  --chunk-size 20 \
  --image-size 128 \
  --batch-size 8 \
  --num-workers 4 \
  --steps 20 \
  --samples-per-epoch 200 \
  --eval-batches 2 \
  --eval-every 10 \
  --save-every 20 \
  --max-episodes-per-split 50 \
  --amp

