from __future__ import annotations

import argparse
import csv
from pathlib import Path

import wandb


RUNS = [
    ("baseB_20k", "outputs/act_base_splitB"),
    ("jointABC_chunk20_20k", "outputs/act_chunk20"),
    ("jointABC_chunk10_10k", "outputs/act_chunk10_10k"),
    ("jointABC_chunk30_10k", "outputs/act_chunk30_10k"),
]


def log_metrics(run_name: str, run_dir: Path) -> None:
    metrics_path = run_dir / "metrics.csv"
    if not metrics_path.exists():
        return
    with metrics_path.open(newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            step = int(row["step"])
            log_row = {}
            for key, value in row.items():
                if key == "step":
                    continue
                try:
                    log_row[f"{run_name}/{key}"] = float(value)
                except ValueError:
                    pass
            wandb.log(log_row, step=step)


def log_images(root: Path) -> None:
    for rel in [
        "figures/convergence_train_l1.png",
        "figures/eval_raw_action_l1_curves.png",
        "figures/zero_shot_splitD_action_error.png",
        "figures/action_chunking_splitD.png",
    ]:
        path = root / rel
        if path.exists():
            wandb.log({rel: wandb.Image(str(path))})


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results-root", type=Path, required=True)
    parser.add_argument("--wandb-dir", type=Path, required=True)
    args = parser.parse_args()

    args.wandb_dir.mkdir(parents=True, exist_ok=True)
    run = wandb.init(
        project="calvin-act-task2",
        name="offline-summary",
        mode="offline",
        dir=str(args.wandb_dir),
        config={"dataset": "xiaoma26/calvin-lerobot", "policy": "ACT"},
    )
    try:
        for run_name, rel_dir in RUNS:
            log_metrics(run_name, args.results_root / rel_dir)
        log_images(args.results_root)
    finally:
        run.finish()


if __name__ == "__main__":
    main()

