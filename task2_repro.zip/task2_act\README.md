# CALVIN LeRobot ACT Task 2

This directory contains the training and evaluation code for the assignment's second task.
It trains LeRobot's official `ACTPolicy` on CALVIN LeRobot v2.1 parquet data.

Required experiment protocol:

- Base policy: train on `splitB` only.
- Joint policy: train on `splitA + splitB + splitC`.
- Zero-shot evaluation: test both policies on unseen `splitD`.
- Action chunking: compare different ACT chunk sizes under visual distribution shift.

The dataloader reads the v2.1 parquet files directly because LeRobot 0.4.x expects the newer v3 layout. Images are decoded from PNG bytes and resized to 128x128. The policy consumes:

- `observation.images.image`
- `observation.images.wrist_image`
- `observation.state`
- `action`
- `action_is_pad`

Quick smoke test:

```bash
bash run_smoke.sh
```

Base policy on environment B:

```bash
bash run_train_baseB.sh
```

Joint A+B+C policy with chunk size 20:

```bash
bash run_train_chunk20.sh
```

Generate summary figures after downloading results:

```bash
python plot_task2_summary.py --results-root ../task2_results
```

For ablation, run `train_act.py` with the same architecture and change only `--chunk-size` plus output directory, e.g. `10`, `20`, `30`.
